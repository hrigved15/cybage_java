package controler;



import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import connectionUtil.JdbcConnection;
import dao.RegisterDao;

/**
 * Servlet implementation class Register
 */
@WebServlet("/Register")
public class Register extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Register() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		RegisterDao rdao=new RegisterDao();

		String empId=request.getParameter("empid");
		String password=request.getParameter("password");
		String name=request.getParameter("name");
		String dept=request.getParameter("department");
		int row = 0;

		try 
		{
			row=rdao.register(empId, password, name, dept);

		}
		catch (SQLException e) {
			request.setAttribute("msg1", "Employee id : "+empId +" already registered...please try again");
			RequestDispatcher rd=request.getRequestDispatcher("Register.jsp");
			rd.forward(request, response);
			e.printStackTrace();

		}
		if(row!=0)
		{
			request.setAttribute("msg1", "You Are successfully registered with employee Id : "+empId+"...Now Login");
			RequestDispatcher rd=request.getRequestDispatcher("login.jsp");
			rd.forward(request, response);
		}
		else
		{
			request.setAttribute("msg1", "Unable to register, please try again...");
			RequestDispatcher rd=request.getRequestDispatcher("Register.jsp");
			rd.forward(request, response);
		}

	}		


}

