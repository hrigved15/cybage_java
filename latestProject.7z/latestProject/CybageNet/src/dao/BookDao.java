package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import connectionUtil.JdbcConnection;
import pojos.Book;
import pojos.Employee;

public class BookDao {

	private Connection conn;
	private PreparedStatement pst1 ;
	ResultSet resultSet;
	Employee emp = null;

	public BookDao() 
	{
System.out.println("in  BookDao()");
		
	}
	public void cleanUp() throws Exception {
		System.out.println("in  cleanUp()");

		if (pst1 != null)
			pst1.close();
		if (resultSet != null)
			resultSet.close();
		conn.close();

	}
	public ArrayList<Book> getBookDetails(String bookName) {
		ArrayList<Book> list1 = null;
		System.out.println("in  getBookDetails of dao..");
		conn=JdbcConnection.getConn();

		try {
			pst1 = conn.prepareStatement("select * from books where bookname=?");

			pst1.setString(1, bookName);
			resultSet=pst1.executeQuery();

			if (resultSet.next()) 
			{
				resultSet.previous();
				list1 = new ArrayList<Book>();
				while (resultSet.next()) 
				{
					list1.add(new Book(resultSet.getInt(1), resultSet.getString(2), resultSet.getDouble(3),
							resultSet.getString(4), resultSet.getString(5)));
				}

			}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	
	

	try {
		cleanUp();
	} catch (Exception e) {

		e.printStackTrace();
	}
	return list1; 

}


}
