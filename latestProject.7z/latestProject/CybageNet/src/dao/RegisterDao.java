package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import connectionUtil.JdbcConnection;
import pojos.Employee;

public class RegisterDao {
	private Connection conn;
	private PreparedStatement pst1 ;
	ResultSet rst;
	Employee emp = null;
	
	public RegisterDao() 
	{
			conn=JdbcConnection.getConn();
	}
	public void cleanUp() throws Exception {
		
		if (pst1 != null)
			pst1.close();
		
		conn.close();
		
	}
	
	public int register(String empId,String password,String name,String dept) throws SQLException {
		
			pst1 = conn.prepareStatement("Insert into cybageemployee values(?,?,?,?,'U')");

			pst1.setString(1, empId);
			pst1.setString(2, password);
			pst1.setString(3, name);
			pst1.setString(4, dept);
			int row = pst1.executeUpdate();

		
	try {
		cleanUp();
	} catch (Exception e) {
		
		e.printStackTrace();
	}
		
		return row; 
		
	}
}
