package beans;

import java.util.ArrayList;
import dao.BookDao;
import dao.BookReviewDao;
import pojos.Book;

public class BookBean {
	private int bookId;
	private String bookName;
	private double price;
	private String author;
	private String category;

	private BookDao bookDao;
	private BookReviewDao bookReviewDao;
	
	public BookBean() {
		bookDao=new BookDao();
		bookReviewDao=new BookReviewDao();
	}
	
	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	} 
	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {

		this.bookName = bookName;
	}
	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}
	
	
	public ArrayList<Book> getBookDetails() throws Exception {

		return bookDao.getBookDetails(bookName);
	}
	public ArrayList<String> getBookReviews()
	{
		return bookReviewDao.getBookReviews(bookId);
	}
}
