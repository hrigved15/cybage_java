package servers;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class SimpleServer {
	public static final int SERVER_PORT = 3000;

	public static void main(String[] args) {
		System.out.println("waiting for clnt request");
		try (ServerSocket ss = new ServerSocket(SERVER_PORT, 1);
				Socket ds = ss.accept();) {
			System.out.println("accepted cn from clnt IP "
					+ ds.getInetAddress().getHostName() + " rem port "
					+ ds.getPort() + "on local port " + ds.getLocalPort());
			// attach suitable data strms
			try (// o/p
			PrintWriter pw = new PrintWriter(ds.getOutputStream(),true);
					BufferedReader br = new BufferedReader(
							new InputStreamReader(ds.getInputStream()))) {
				//read req
				System.out.println("clnt sent : "+br.readLine());
				//send resp
				pw.println("I m good, BYE for now...");

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
