package clnts;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class SimpleClient {
	public static final int SERVER_PORT = 3000;
	public static final String SERVER_IP = "127.0.0.1";

	public static void main(String[] args) {
		try (Socket s1 = new Socket(SERVER_IP, SERVER_PORT)) {
			System.out.println("connected to IP "
					+ s1.getInetAddress().getHostName() + " rem port "
					+ s1.getPort() + " local port " + s1.getLocalPort());
			try (// o/p
			PrintWriter pw = new PrintWriter(s1.getOutputStream(),true);
					BufferedReader br = new BufferedReader(
							new InputStreamReader(s1.getInputStream()))) {
				//clnt send req
				pw.println("Hello server , how r u?");
				//read resp from server n display
				System.out.println("server responded :  "+br.readLine());

			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
