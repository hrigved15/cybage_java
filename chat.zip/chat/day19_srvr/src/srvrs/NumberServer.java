package srvrs;

import java.awt.Font;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.DataInputStream;
import java.io.DataOutput;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashSet;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class NumberServer extends JFrame {
	private JTextArea jta;
	// net
	private ServerSocket ss;
	private Socket ds;

	public static void main(String[] args) {
		try {
			NumberServer ns = new NumberServer();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public NumberServer() throws Exception {
		initGUI();
		initBL();
	}

	private void initGUI() {
		setTitle("Number server");
		setSize(600, 600);
		jta = new JTextArea(20, 80);
		jta.setFont(new Font("tahoma", Font.BOLD, 20));
		JScrollPane jsp = new JScrollPane(jta);
		add(jsp);
		addWindowListener(new WindowAdapter() {

			@Override
			public void windowClosing(WindowEvent e) {
				if (ss != null)
					try {
						ss.close();
						System.exit(0);
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						System.out.println("err in win closing " + e1);
					}// no new clnts
			}

		});

		setVisible(true);
	}

	private void initBL() throws Exception {
		jta.append("waiting for clnt conn\n");
		// ss
		ss = new ServerSocket(5000, 1);
		// ds
		ds = ss.accept();
		// attach data strms
		DataOutputStream out = new DataOutputStream(ds.getOutputStream());
		ObjectInputStream in = new ObjectInputStream(ds.getInputStream());
		jta.append("attached data strms\n");
		try {
			while (true) {
				service(in, out);
			}
		} catch (EOFException e) {
			// clnt sock closed
			if (ds != null)
				ds.close();
			jta.append("clnt appln terminated, can close server\n");
		}
	}

	@SuppressWarnings("unchecked")
	private void service(ObjectInputStream in, DataOutputStream out)
			throws Exception {
		// restore HS
		HashSet<Integer> ints = (HashSet<Integer>) in.readObject();
		jta.append("recvd nums " + ints + "\n");
		// read cmd
		double result = 0;
		switch (in.readUTF()) {
		case "add":
			for (int i : ints)
				result += i;
			break;
		case "multiply":
			result = 1;
			for (int i : ints)
				result *= i;
			break;
		}
		// send res to clnt
		jta.append("sending resp " + result + "\n");
		out.writeDouble(result);

	}

}
