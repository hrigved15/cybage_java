package srvrs;

import java.awt.Font;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.DataInputStream;
import java.io.DataOutput;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.HashSet;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class NumberServerThreaded extends JFrame {
	private JTextArea jta;
	// net
	private ServerSocket ss;

	public static void main(String[] args) {
		try {
			NumberServerThreaded ns = new NumberServerThreaded();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public NumberServerThreaded() throws Exception {
		initGUI();
		initBL();
	}

	private void initGUI() {
		setTitle("Number server");
		setSize(600, 600);
		jta = new JTextArea(20, 80);
		jta.setFont(new Font("tahoma", Font.BOLD, 20));
		JScrollPane jsp = new JScrollPane(jta);
		add(jsp);
		addWindowListener(new WindowAdapter() {

			@Override
			public void windowClosing(WindowEvent e) {
				if (ss != null)
					try {
						ss.close();

					} catch (IOException e1) {
						// TODO Auto-generated catch block
						System.out.println("err in win closing " + e1);
					}// no new clnts
			}

		});

		setVisible(true);
	}

	private void initBL() throws Exception {

		// ss
		ss = new ServerSocket(5000, 10);
		// create emptyAL<Thrd>
		ArrayList<Thread> thrds = new ArrayList<>();
		try {
			while (true) {
				jta.append("waiting for clnt conn\n");
				// ds
				Socket ds = ss.accept();
				thrds.add(new ClntHandler(ds));

			}
		} catch (SocketException e) {
			System.out.println(e);
			System.out.println("server can't accept any new cns...");
		}
		// no new clnts
		for (Thread t : thrds)
			t.join();
		System.out.println("all clnts over...shutting dow server");
		System.exit(0);
	}

	@SuppressWarnings("unchecked")
	private void service(ObjectInputStream in, DataOutputStream out)
			throws Exception {
		// restore HS
		HashSet<Integer> ints = (HashSet<Integer>) in.readObject();
		jta.append("recvd nums " + ints + "\n");
		// read cmd
		double result = 0;
		switch (in.readUTF()) {
		case "add":
			for (int i : ints)
				result += i;
			break;
		case "multiply":
			result = 1;
			for (int i : ints)
				result *= i;
			break;
		}
		// send res to clnt
		jta.append("sending resp " + result + "\n");
		out.writeDouble(result);

	}

	// inner class for clnt servicing
	class ClntHandler extends Thread {
		private Socket ds;

		public ClntHandler(Socket ds) {
			this.ds = ds;
			start();
		}

		@Override
		public void run() {
			try {
				jta.append("thrd strted " + Thread.currentThread().getName()
						+ "\n");
				// attach data strms
				DataOutputStream out = new DataOutputStream(
						ds.getOutputStream());
				ObjectInputStream in = new ObjectInputStream(
						ds.getInputStream());
				jta.append("attached data strms"
						+ Thread.currentThread().getName() + "\n");
				while (true)
					service(in, out);
			} catch (Exception e) {
				if (e instanceof EOFException) {
					jta.append("clnt of " + Thread.currentThread().getName()
							+ " terminated\n");
					if (ds != null)
						try {
							ds.close();
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
				} else
					System.out.println("err in thrd "
							+ Thread.currentThread().getName() + " " + e);
			}
			jta.append("thrd over " + Thread.currentThread().getName() + "\n");
		}
	}

}
