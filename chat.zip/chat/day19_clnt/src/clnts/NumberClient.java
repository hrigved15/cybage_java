package clnts;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.DataInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.util.HashSet;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class NumberClient extends JFrame implements ActionListener {
	private JLabel[] lables;
	private JTextField nums, res;
	private JComboBox<String> cmds;
	private JButton exec;
	// net clnt
	private Socket s;
	private ObjectOutputStream out;
	private DataInputStream in;

	public static void main(String[] args) {
		try {
			NumberClient n = new NumberClient();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public NumberClient() throws Exception {
		initGUI();
		initBL();
	}

	private void initGUI() {
		setTitle("Number Client");
		setSize(400, 200);
		String[] names = { "Enter Nums", "Command", "Result" };
		lables = new JLabel[names.length];
		for (int i = 0; i < lables.length; i++)
			lables[i] = new JLabel(names[i]);
		JPanel p1 = new JPanel(new GridLayout(3, 2, 20, 40));
		p1.add(lables[0]);
		nums = new JTextField(40);
		p1.add(nums);
		p1.add(lables[1]);
		String[] nms = { "add", "multiply" };
		cmds = new JComboBox<>(nms);
		p1.add(cmds);
		p1.add(lables[2]);
		res = new JTextField(40);
		res.setEditable(false);
		p1.add(res);
		add(p1);
		exec = new JButton("Execute");
		exec.addActionListener(this);
		add(exec, BorderLayout.SOUTH);
		// win closing
		addWindowListener(new WindowAdapter() {

			@Override
			public void windowClosing(WindowEvent e) {
				try {
					// close sock
					if (s != null)
						s.close();
					System.exit(0);
				} catch (Exception e1) {
					System.out.println("err in win closing " + e1);
				}
			}

		});

		setVisible(true);
	}

	private void initBL() throws Exception {
		// cn establisment --sock
		InetAddress ip = InetAddress.getByName("localhost");
		s = new Socket(ip, 5000);
		// attach data strms
		out = new ObjectOutputStream(s.getOutputStream());
		out.flush();// to flush serial stream header.
		in = new DataInputStream(s.getInputStream());
		System.out.println("data strms attached");
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		try {
			// HS
			HashSet<Integer> hs = new HashSet<>();
			// attach sc to string from tf
			Scanner sc = new Scanner(nums.getText());
			while (sc.hasNextInt())
				hs.add(sc.nextInt());
			// cmd
			String cmd = cmds.getSelectedItem().toString();
			// send nums n cmd to server
			out.writeObject(hs);
			out.writeUTF(cmd);
			out.flush();
			//read res n add it tf
			res.setText(""+in.readDouble());
		} catch (Exception e1) {
			System.out.println("err in aP " + e1);
		}

	}

}
