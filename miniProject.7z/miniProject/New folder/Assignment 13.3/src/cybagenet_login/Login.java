package cybagenet_login;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import pojos.Employee;

/**
 * Servlet implementation class Login
 */

@WebServlet("/Login")
public class Login extends HttpServlet {
	ServletContext context;
	private static final long serialVersionUID = 1L;

	@Override
	public void init() throws ServletException {
		context=getServletContext();
		context.setAttribute("activeUsersCount", 0);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession hs=request.getSession();
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();

		String email = request.getParameter("email");
		String pass = request.getParameter("password");
		Employee emp1=Validate.checkUser(email, pass);

		RequestDispatcher rs;
		if (emp1!=null ) {
			if(emp1.getRole().equalsIgnoreCase("A")){
				hs.setAttribute("admin", emp1);
				rs = request.getRequestDispatcher("AdminHome");
				rs.forward(request, response);

			}
			else {
				context=getServletContext();
				Integer activeUsrsCount=(Integer)context.getAttribute("activeUsersCount");
				if (activeUsrsCount==null) {
					activeUsrsCount=0;
				}

				context.setAttribute("activeUsersCount", activeUsrsCount+1);
				hs.setAttribute("employee", emp1);
				rs = request.getRequestDispatcher("UserHome");
				rs.forward(request, response);
			}
		} else {
			out.println("<font color='red'>Username or Password incorrect</font>");
			out.print("<br><h3>Try Again</h3>");
			rs = request.getRequestDispatcher("index.html");
			rs.include(request, response);
		}
	}
}
