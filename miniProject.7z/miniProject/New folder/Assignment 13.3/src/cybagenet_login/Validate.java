package cybagenet_login;

import static util.Util.getMySqlCon;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import pojos.Employee;

public class Validate
{
	public static Employee checkUser(String email,String pass) 
	{
		Employee employee1=null; 
		boolean st =false;
		try{
			//getting connection instance with the database 
			Connection con=getMySqlCon();
			
			PreparedStatement ps =con.prepareStatement
					("select * from employee where email=? and password=?");
			ps.setString(1, email);
			ps.setString(2, pass);
			ResultSet rs =ps.executeQuery();
			
			if(rs.next())
			{
				employee1=new Employee(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4),rs.getString(5));
			}

		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return employee1;                 
	}   
}
