package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Util {
	public static Connection con=null;
	public static Connection getMySqlCon() throws ClassNotFoundException, SQLException {
		
		// loading and registering mysql driver to jdbc
		Class.forName("com.mysql.jdbc.Driver");
	
		// opening a connection using database URL , username and password
		if(con==null)//to ensure singleton connection object
		 con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "root");
		
		return con;

	}
}