package pojos;

public class Employee {
	
	int empId;
	String empName;
	String email;
	String password;
	String role;
	public Employee(int empId, String empName, String email, String password,String role) {
		
		this.empId = empId;
		this.empName = empName;
		this.email = email;
		this.password = password;
		this.role=role;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", email=" + email + ", password=" + password
				+ ", role=" + role + "]";
	}
	
	
	
}
