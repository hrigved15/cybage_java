package pojos;

public class Book {
	long isbnno;
	String bookName;
	double price;
	String author;
	String publication;
	public Book(long isbnno, String bookName, double price, String author, String publication) {
		super();
		this.isbnno = isbnno;
		this.bookName = bookName;
		this.price = price;
		this.author = author;
		this.publication = publication;
	}
	public long getIsbnno() {
		return isbnno;
	}
	public void setIsbnno(long isbnno) {
		this.isbnno = isbnno;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getPublication() {
		return publication;
	}
	public void setPublication(String publication) {
		this.publication = publication;
	}
	@Override
	public String toString() {
		return "Book [isbnno=" + isbnno + ", bookName=" + bookName + ", price=" + price + ", author=" + author
				+ ", publication=" + publication + "]";
	}
	
	
}
