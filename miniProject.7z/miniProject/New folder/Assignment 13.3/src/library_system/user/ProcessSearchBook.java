package library_system.user;

import static util.Util.getMySqlCon;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ProcessSearchBook
 */
@WebServlet("/ProcessSearchBook")
public class ProcessSearchBook extends HttpServlet {
	private static final long serialVersionUID = 1L;

	Connection con;
	PreparedStatement pstSearchBook;

	@Override
	public void init() throws ServletException {

		try {
			con = getMySqlCon();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(
					"select * from book where BookName like '%" + request.getParameter("bookName") + "%'");
			ResultSetMetaData rsmd = rs.getMetaData();
			out.println("<table border=1>");
			out.println("<tr>");
			out.println("<th>" + rsmd.getColumnName(1).toUpperCase() + "</th>");
			out.println("<th>" + rsmd.getColumnName(2).toUpperCase() + "</th>");
			out.println("<th>" + rsmd.getColumnName(3).toUpperCase() + "</th>");
			out.println("<th>" + rsmd.getColumnName(4).toUpperCase() + "</th>");
			out.println("<th>" + rsmd.getColumnName(5).toUpperCase() + "</th>");
			out.println("<th colspan='2'> Actoions </th>");
			out.println("</tr>");
			while (rs.next()) {
				long isbn=rs.getLong(1);
				out.println("<tr>");
				out.println("<td>" +isbn + "</td>");
				out.println("<td>" + rs.getString(2) + "</td>");
				out.println("<td>" + rs.getDouble(3) + "</td>");
				out.println("<td>" + rs.getString(4) + "</td>");
				out.println("<td>" + rs.getString(5) + "</td>");
				out.println("<form method='POST' action='AddReview'>");
				out.println("<input type='hidden' name='isbn' value='"+isbn+"'>");
				out.println("<td>" +"<input type='submit' value='Add Review'>" + "</td>");
				out.println("</form>");
				out.println("<form method='POST' action='ShowReview'>");
				out.println("<input type='hidden' name='isbn' value='"+isbn+"'>");
				out.println("<td>" +"<input type='submit' value='Show Review'>" + "</td>");
				out.println("</form>");
				
				out.println("</tr>");
			}
			out.println("</table>");

		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

}
