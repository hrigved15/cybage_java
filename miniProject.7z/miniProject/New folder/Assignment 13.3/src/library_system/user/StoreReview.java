package library_system.user;

import static util.Util.getMySqlCon;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class StoreReview
 */
@WebServlet("/StoreReview")
public class StoreReview extends HttpServlet {
	private static final long serialVersionUID = 1L;

	Connection con;
	PreparedStatement pstStoreReview,pstUpdateReview;

	@Override
	public void init() throws ServletException {

		try {
			con = getMySqlCon();
			pstStoreReview =con.prepareStatement("insert into book_reviews values(?,?,?)");
			pstUpdateReview=con.prepareStatement("update book_reviews set review=? where isbnno=? and empid=?");
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}

	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		long isbnno=Long.parseLong(request.getParameter("isbnno"));
		int empid=Integer.parseInt(request.getParameter("empid"));
		String review=request.getParameter("review");
		int noOfRowsUpdated=0;
		
		try {
			pstStoreReview.setLong(1, isbnno);
			pstStoreReview.setInt(2, empid);
			pstStoreReview.setString(3, review);
			noOfRowsUpdated=pstStoreReview.executeUpdate();

		} catch (SQLException e) {
			try {
				pstUpdateReview.setLong(2, isbnno);
				pstUpdateReview.setInt(3, empid);
				pstUpdateReview.setString(1, review);
				noOfRowsUpdated=pstUpdateReview.executeUpdate();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		}
		if(noOfRowsUpdated>0)
			out.println("Review Added successfully");
		else
			out.print("Review not added");
		out.println("<br><a href='UserHome'>Home</a>");

	}

}
