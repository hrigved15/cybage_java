package library_system.user;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import pojos.Employee;

/**
 * Servlet implementation class AddReview
 */
@WebServlet("/AddReview")
public class AddReview extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		long isbn=Long.parseLong(request.getParameter("isbn")); 
		HttpSession hs=request.getSession();
		int empid=0;
		Employee emp;
		RequestDispatcher rs;
		try{
			emp=(Employee)hs.getAttribute("employee");
			empid=emp.getEmpId();
			out.println("<form Action='StoreReview' method='post'>");
			out.println("Employee ID: <input type='text' name='empid' value='"+empid+"'>"+"<br>");
			out.println("ISBN NO: <input type='text' name='isbnno' value='"+isbn+"'>"+"<br>");
			out.println("Type Review: <textarea rows='4' cols='50' name='review'>");
			out.print("</textarea>");
			out.print("<br>");
			out.print("<br>");
			out.println("<input type='submit' value='Submit Review'>");

			out.print("</form>");
		}
		catch(NullPointerException npe)
		{
			out.println("<font color='red'>Session Expired</font>");
			out.print("<br><h3>Please Login</h3>");
			rs = request.getRequestDispatcher("index.html");
			rs.include(request, response);

		}


	}


}
