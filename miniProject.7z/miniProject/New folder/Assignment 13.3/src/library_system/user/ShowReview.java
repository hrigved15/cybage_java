package library_system.user;

import static util.Util.getMySqlCon;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import pojos.Employee;

/**
 * Servlet implementation class ShowReview
 */
@WebServlet("/ShowReview")
public class ShowReview extends HttpServlet {
	private static final long serialVersionUID = 1L;

	Connection con;
	PreparedStatement pstShowReview;

	@Override
	public void init() throws ServletException {

		try {
			con = getMySqlCon();
			pstShowReview=con.prepareStatement("select * from book_reviews where isbnno=?");
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		long isbn=Long.parseLong(request.getParameter("isbn"));
		out.println("<h2>ISBN Number: "+isbn+"</h2><br>");
		try{
			pstShowReview.setLong(1, isbn);
			ResultSet rs=pstShowReview.executeQuery();
			ResultSetMetaData rsmd = rs.getMetaData();
			out.println("<table border=1>");
			out.println("<tr>");
			//out.println("<th>" + rsmd.getColumnName(1).toUpperCase() + "</th>");
			out.println("<th>" + rsmd.getColumnName(2).toUpperCase() + "</th>");
			out.println("<th>" + rsmd.getColumnName(3).toUpperCase() + "</th>");

			out.println("</tr>");

			while (rs.next()) {
				out.println("<tr>");
				out.println("<td>" + rs.getInt(2) + "</td>");
				out.println("<td>" + rs.getString(3) + "</td>");
				out.println("</tr>");
			}
			out.println("</table>");
			
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}


	}

}
