package library_system.admin;

import static util.Util.getMySqlCon;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class RemoveBook
 */
@WebServlet("/RemoveBook")
public class RemoveBook extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	Connection con;

	@Override
	public void init() throws ServletException {
		
		try {
			con = getMySqlCon();
		} catch (ClassNotFoundException | SQLException e) {

			e.printStackTrace();
		}

	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("in doPost()");
		out.println("<form mehtod='post' action='ProcessRemoveBook'>");
		out.println("ISBN: <input type='text' name='isbn'>"+"<br>");
		
		out.println("<input type='submit' name='submit' value='Remove Book'>"+"<br>");
		out.println("</form>");
		
	}

}
