package library_system.admin;

import static util.Util.getMySqlCon;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class InsertBook
 */
@WebServlet("/InsertBook")
public class InsertBook extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request,response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("in doPost()");
		out.println("<form mehtod='post' action='ProcessInsertion'>");
		out.println("ISBN: <input type='text' name='isbn'>"+"<br>");
		out.println("Book Name: <input type='text' name='bkname'>"+"<br>");
		out.println("Price: <input type='text' name='price'>"+"<br>");
		out.println("Author: <input type='text' name='author'>"+"<br>");
		out.println("Publication: <input type='text' name='publication'>"+"<br>");
		out.println("<input type='submit' name='submit' value='Submit'>"+"<br>");
		out.println("</form>");
		
		
	}
}
