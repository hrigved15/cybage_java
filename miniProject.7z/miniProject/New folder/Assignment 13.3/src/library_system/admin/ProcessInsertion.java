package library_system.admin;

import static util.Util.getMySqlCon;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ProcessInsertion
 */
@WebServlet("/ProcessInsertion")
public class ProcessInsertion extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection con;
	PreparedStatement pstInsertBook;

	@Override
	public void init() throws ServletException {

		try {
			con = getMySqlCon();
			pstInsertBook = con.prepareStatement("insert into book values(?,?,?,?,?)");
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		int isbn = Integer.parseInt(request.getParameter("isbn"));
		String bkname = request.getParameter("bkname");
		double price = Double.parseDouble(request.getParameter("price"));
		String author = request.getParameter("author");
		String publication = request.getParameter("publication");

		try {
			pstInsertBook.setInt(1, isbn);
			pstInsertBook.setString(2, bkname);
			pstInsertBook.setDouble(3, price);
			pstInsertBook.setString(4, author);
			pstInsertBook.setString(5, publication);
			int rowsUpdated = pstInsertBook.executeUpdate();
			
			if (rowsUpdated == 1)
				out.println("<h3>Book Added to database successfully</h3>");

			/* out.println("<a href='AdminHome'>Home</a>"); */
		} catch (SQLException e) {
			out.println("<font color='red'>Book not added</font>");

		} finally {
			out.println("<br><a href='AdminHome'>Home</a>");
			out.println("<br>");
			out.println("<a href='index.html'>Logout</a>");
		}
	}

	
}
