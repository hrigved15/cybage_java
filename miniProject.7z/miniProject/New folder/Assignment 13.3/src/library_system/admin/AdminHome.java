package library_system.admin;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import pojos.Employee;

/**
 * Servlet implementation class Welcome
 */
@WebServlet("/AdminHome")
public class AdminHome extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ServletContext context;

	@Override
	public void init() throws ServletException {
		context=getServletContext();
	}

	

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		HttpSession hs=request.getSession();
		Employee employee=(Employee)hs.getAttribute("admin");
		out.println("Welcome "+employee.getEmpName());
		
		Integer activeUsrsCount=(Integer)context.getAttribute("activeUsersCount");
		context=getServletContext();
		System.out.println(context.getAttribute("activeUsersCount"));
		if (activeUsrsCount==null) {
			activeUsrsCount=0;
		}
			
		
		out.println("<br>");
		out.println("<a href='insertbook.html'>Add new book to database</a>");
		out.println("<br>");
		out.println("<a href='removebook.html'>Remove book from database</a>");
		out.println("<br>");
		out.println("<a href='Logout'>Logout</a>");
		out.println("<h2>No of Active(Logged In) Users"+activeUsrsCount+"<h2>");
	}

}
