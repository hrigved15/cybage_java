package library_system.admin;

import static util.Util.getMySqlCon;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ProcessRemoveBook
 */
@WebServlet("/ProcessRemoveBook")
public class ProcessRemoveBook extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection con;
	PreparedStatement pstRemoveBook;

	@Override
	public void init() throws ServletException {

		try {
			con = getMySqlCon();
			pstRemoveBook=con.prepareStatement("delete from book where isbnno=?");
		

		} catch (ClassNotFoundException | SQLException e) {

			e.printStackTrace();
		}

	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		int isbn=Integer.parseInt(request.getParameter("isbn"));
		

		try {
			pstRemoveBook.setInt(1, isbn);
			
			int rowsUpdated=pstRemoveBook.executeUpdate();
			if(rowsUpdated==1)
				out.println("<h3>Book Removed from database successfully</h3>");
			else
				out.println("<font color='red'>Book not removed</font>");
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		finally {
			out.println("<br><a href='AdminHome'>Home</a>");
			out.println("<br>");
			out.println("<a href='index.html'>Logout</a>");
		}
	}


}
