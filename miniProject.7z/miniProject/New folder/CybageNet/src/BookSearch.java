

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class BookSearch
 */
@WebServlet("/BookSearch")
public class BookSearch extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public BookSearch() {
		super();
		// TODO Auto-generated constructor stub
	}



	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		String bookName=request.getParameter("bookname");
		System.out.println(bookName);
		try {
			Connection conn=JdbcConnection.getConn();
			PreparedStatement pst1 = conn.prepareStatement("Select * from cybagebooks where bookname=?");
			pst1.setString(1, bookName); 
			ResultSet rs=pst1.executeQuery();
			/*int i=0;
			while(rst.next())
			{i++;
				request.setAttribute("bookId"+i,rst.getInt(1));
				request.setAttribute("bookName"+i,rst.getString(2));
				request.setAttribute("bookAuthor"+i,rst.getString(3));
				
			}*/
			 /* String tr="";
			  while(rs.next()){
			  tr=tr+"<tr>";
			  tr=tr+"<td>"+rs.getInt(1)+"  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  "+"</td>";
			  tr=tr+"<td>"+rs.getString(2)+"  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;     "+"</td>";
			  tr=tr+"<td>"+rs.getString(3)+" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;      "+"</td>";
			  tr=tr+"</tr>";
			  }
			  String table="<table border='1'>"+tr+"</table>";
			  pw.write(table);*/
			
			
			pw.println("<form action='BookSearch' method='post'>"); 
			while(rs.next()) 
			{ 
			pw.println("<div>"+rs.getInt(1)+"</div>"); 
			pw.println("<div>"+rs.getString(2)+"</div>");
			pw.println("<div>"+rs.getString(3)+"</div>");
			} 
			pw.println("</form>");
			  RequestDispatcher rd=request.getRequestDispatcher("User.jsp");
				rd.include(request, response);
			  pw.close();
		}catch (ClassNotFoundException e) {
			e.printStackTrace();
		} 
		catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
