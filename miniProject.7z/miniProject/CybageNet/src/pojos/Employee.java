package pojos;

public class Employee {
	int empId;
	String empName;
	String password;
	String department;
	String role;

	public Employee(int empId, String empName, String password, String department, String role) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.password = password;
		this.department = department;
		this.role = role;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", password=" + password + ", department="
				+ department + ", role=" + role + "]";
	}


}
