package logic;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*; 
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import db.DbConnector;

/**
 * Servlet implementation class UpdateBook
 */
@WebServlet("/RemoveBook")
public class RemoveBook extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public RemoveBook() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out =	response.getWriter();


		try (Connection	con = DbConnector.getConnection())
		{
	
			String query1 = "select * from bookdetails" ;


			PreparedStatement pst1 = con.prepareCall(query1);

			//executing query
			ResultSet rs = pst1.executeQuery();
			out.println("<form action = 'RemoveBook' method = 'post'><table align='center' border = 2 bgcolor=cyan>");
			out.println("<tr><td>Book Id</td><td>Book Name</td><td>Author Name</td><td>Book Pages</td></tr>");
			//loop till last row in result set
			while(rs.next())
			{		
				out.println("<tr><td>"+rs.getInt(1)+"</td><td>"+rs.getString(2)+"</td><td>"+rs.getString(3)+"</td><td>"+rs.getInt(4)+"</td></tr>");
			}

			out.println("</table>");
			out.println("  <input type='text' name='bookName' >");
			out.println(" <input type='submit' value='Submit'>");	
			out.println("</form>");
			

		} catch (SQLException  e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		try (Connection	con = DbConnector.getConnection())
		{
	
			String query1 =  "DELETE FROM bookdetails WHERE bname='"+request.getParameter("bookName")+"'" ;
			Statement pst1 = con.createStatement();
			pst1.executeUpdate(query1);
			System.out.println("deleted successfully");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
