package logic;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*; 

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import db.DbConnector;

/**
 * Servlet implementation class InsertBook
 */
@WebServlet("/InsertBook")
public class InsertBook extends HttpServlet {
	private static final long serialVersionUID = 1L;
	PreparedStatement insertInBook ;
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public InsertBook() {
		super();

		//getting connection
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		out.println("<form action = 'InsertBook' method = 'post'><table align='center' border = 2 bgcolor=cyan>");
		out.println("<tr><td>Enter Book Name        : </td><td><input type='text' name = 'name'></td></tr>");
		out.println("<tr><td>Enter Author Name      : </td><td><input type='text' name = 'author'></td></tr>");
		out.println("<tr><td>Enter Book Pages       : </td><td><input type='text' name = 'pages'></td></tr>");
		out.println("<tr><td><input type='submit' value='Insert Book'></td></tr>");
		out.println("</table></form>");

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//getting value from request parameter
		String name = request.getParameter("name");
		String author = request.getParameter("author");
		int pages = Integer.parseInt((request.getParameter("pages")));


		try (Connection	con = DbConnector.getConnection())
		{
			
			String query = "insert into bookdetails(bname, bauther, pages) values(?,?,?)";
			insertInBook = con.prepareStatement(query);
			insertInBook.setString(1,name);
			insertInBook.setString(2,author);
			insertInBook.setInt(3,pages);
			insertInBook.execute();

		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}

		response.getWriter().println("Successfully");
	}

}
