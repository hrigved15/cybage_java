package reg;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import db.DbConnector;

/**
 * Servlet implementation class RegistrationForm
 */
@WebServlet("/UserForm")
public class UserForm extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserForm() {
        super();
        
        
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out =	response.getWriter();


		try (Connection	con = DbConnector.getConnection())
		{
	
			String query1 = "select * from bookdetails" ;


			PreparedStatement pst1 = con.prepareCall(query1);

			//executing query
			ResultSet rs = pst1.executeQuery();
			out.println("<form action = 'RemoveBook' method = 'post'><table align='center' border = 2 bgcolor=cyan>");
			out.println("<tr><td>Book Id</td><td>Book Name</td><td>Author Name</td><td>Book Pages</td></tr>");
			//loop till last row in result set
			while(rs.next())
			{		
				out.println("<tr><td><a href='BookDetails?bname="+rs.getString(2)+"'>"+rs.getString(2)+"</a></td></tr>");
			}

			out.println("</table>");
			out.println("</form>");
			

		} catch (SQLException  e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	

	
	}

}
