package reg;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import db.DbConnector;

/**
 * Servlet implementation class BookDetails
 */
@WebServlet("/BookDetails")
public class BookDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BookDetails() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out =	response.getWriter();
		
		System.out.println(request.getParameter("bname"));
		try (Connection	con = DbConnector.getConnection())
		{
	
			String query1 = "select * from bookdetails where bname ='"+request.getParameter("bname")+"'" ;

			PreparedStatement pst1 = con.prepareCall(query1);

			//executing query
			ResultSet rs = pst1.executeQuery();
			out.println("<form action = 'RemoveBook' method = 'post'><table align='center' border = 2 bgcolor=cyan>");
			out.println("<tr><td>Book Id</td><td>Book Name</td><td>Author Name</td><td>Book Pages</td></tr>");
			//loop till last row in result set
			while(rs.next())
			{		
				out.println("<tr><td>"+rs.getInt(1)+"</td><td>"+rs.getString(2)+"</td><td>"+rs.getString(3)+"</td><td>"+rs.getInt(4)+"</td></tr>");
			}

				
			out.println("</table>");
			out.println("</form>");
			

		} catch (SQLException  e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
