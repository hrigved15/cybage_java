package filter;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;

/**
 * Servlet Filter implementation class LogFilter
 */

public class LogFilter implements Filter {


	public LogFilter() {
		// TODO Auto-generated constructor stub
	}


	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		//Getting parameters from request 
		String username = request.getParameter("j_username"); 
		String password = request.getParameter("j_password");

		//comparing admin name.
		if(username.equals("Aniket") && password.equals("1234"))
		{
			System.out.println("Filter entered.....");
			chain.doFilter(request, response);
			System.out.println("Filter returned.....");
		}
		else
		{	 	//if login is by user.
			if(username.equals("Mahesh") && password.equals("1234"))
			{
				RequestDispatcher rq = request.getRequestDispatcher("UserForm");
				rq.forward(request, response);
			}
			else
			{
				RequestDispatcher rq = request.getRequestDispatcher("index.jsp");
				rq.forward(request, response);

			}
		}
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
