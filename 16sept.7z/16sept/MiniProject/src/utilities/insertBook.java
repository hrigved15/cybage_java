package utilities;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;





/**
 * Servlet implementation class insertBook
 */
@WebServlet("/insertBook")
public class insertBook extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public insertBook() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		
		try(Connection con = BaseDAO.getConnection();)
		{
			PreparedStatement statement = con.prepareStatement("insert into books (name,author,price,category) values (?,?,?,?)");
			statement.setString(1, request.getParameter("name"));
			statement.setString(2, request.getParameter("author"));
			statement.setDouble(3, Double.parseDouble(request.getParameter("price")));
			statement.setString(4, request.getParameter("category"));
			
			int result = statement.executeUpdate();
			
			System.out.println(result);
			if( result== 0)
			{
				request.setAttribute("status", "Invalid  Input");
				RequestDispatcher rs = request.getRequestDispatcher("addBook.jsp");
				rs.include(request, response);
			}
			else
			{
				request.setAttribute("status", "Book Added Successfully");
				RequestDispatcher rs = request.getRequestDispatcher("addBook.jsp");
				rs.forward(request, response);
				//response.sendRedirect("addBook.jsp");
			}
			statement.close();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
