package utilities;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class BaseDAO
{
	public static Connection getConnection() throws ClassNotFoundException, SQLException {
		   Class.forName("com.mysql.jdbc.Driver");
		   String url = "jdbc:mysql://localhost:3306/frdb";
		   String name = "root";
		   String password = "root";

		   Connection con = DriverManager.getConnection(url, name, password);
		   return con;
		 }
}
