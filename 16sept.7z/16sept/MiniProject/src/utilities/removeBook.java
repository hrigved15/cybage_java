package utilities;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class removeBook
 */
@WebServlet("/removeBook")
public class removeBook extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public removeBook() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		response.setContentType("text/html");
		
		try(Connection con = BaseDAO.getConnection();)
		{
			PreparedStatement statement = con.prepareStatement("delete from books where id=?");
			statement.setInt(1,Integer.parseInt(request.getParameter("id")));
			
			int result = statement.executeUpdate();
			
			System.out.println(result);
			if( result== 0)
			{
				request.setAttribute("deleteStatus", "Invalid Book Id");
				RequestDispatcher rs = request.getRequestDispatcher("deleteBook.jsp");
				rs.include(request, response);
			}
			else
			{
				request.setAttribute("deleteStatus", "Book Deleted Successfully");
				RequestDispatcher rs = request.getRequestDispatcher("deleteBook.jsp");
				rs.forward(request, response);
			}
			statement.close();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
