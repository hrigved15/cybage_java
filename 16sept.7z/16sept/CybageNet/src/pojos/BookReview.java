package pojos;

public class BookReview {
 
	int reviewId,empId,bookId;
	String review;
	public BookReview(int reviewId, int empId, int bookId, String review) {
		super();
		this.reviewId = reviewId;
		this.empId = empId;
		this.bookId = bookId;
		this.review = review;
	}
	public int getReviewId() {
		return reviewId;
	}
	public void setReviewId(int reviewId) {
		this.reviewId = reviewId;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public int getBookId() {
		return bookId;
	}
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	public String getReview() {
		return review;
	}
	public void setReview(String review) {
		this.review = review;
	}
	@Override
	public String toString() {
		return "BookReview [reviewId=" + reviewId + ", empId=" + empId + ", bookId=" + bookId + ", review=" + review
				+ "]";
	}
	
	
	
}
