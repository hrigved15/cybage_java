package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import connectionUtil.JdbcConnection;
import pojos.Employee;

public class ValidatorDao {
	private Connection conn;
	private PreparedStatement pst1 ;
	ResultSet rst;
	Employee emp = null;
	
	public ValidatorDao() 
	{
			conn=JdbcConnection.getConn();
	}
	public void cleanUp() throws Exception {
		
		if (pst1 != null)
			pst1.close();
		if (rst != null)
			rst.close();
		conn.close();
		
	}
	public Employee validate(String empId) {
		try {
			pst1 = conn.prepareStatement("Select * from cybageemployee where empid=(?)");

			pst1.setString(1, empId);
			rst=pst1.executeQuery();
			
			if(rst.next())
			{
				emp = new Employee(rst.getString(1), rst.getString(3),rst.getString(2),rst.getString(4),rst.getString(5)); 

			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	try {
		cleanUp();
	} catch (Exception e) {
		
		e.printStackTrace();
	}
		return emp; 
		
	}

	
}
