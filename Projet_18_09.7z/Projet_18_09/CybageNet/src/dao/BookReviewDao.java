package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import connectionUtil.JdbcConnection;
import pojos.Book;
import pojos.BookReview;
import pojos.Employee;

public class BookReviewDao {
	private Connection conn;
	private PreparedStatement pst1 ;
	ResultSet resultSet;
	Employee emp = null;
	BookReview review=null;

	public BookReviewDao() 
	{

	}
	public void cleanUp() throws Exception {


		if (pst1 != null)
			pst1.close();
		if (resultSet != null)
			resultSet.close();
		conn.close();

	}
	public int addBookReviews(BookReview review) {
		
		conn=JdbcConnection.getConn();
		int row = 0;
		try {
			pst1 = conn.prepareStatement("Insert into book_reviews(`empid`,`review`,`bookid`) values(?,?,?)");
			
			pst1.setString(1, review.getEmpId());
			pst1.setString(2, review.getReview());
			pst1.setInt(3, review.getBookId());
			
			row = pst1.executeUpdate();

		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}



		try {
			cleanUp();
		} catch (Exception e) {

			e.printStackTrace();
		}
		return row;
		 

	}
	
	public ArrayList<String> getBookReviews(int bookId) {
		ArrayList<String> list1 = null;
		conn=JdbcConnection.getConn();

		try {
			pst1 = conn.prepareStatement("SELECT r.review ,e.name FROM book_reviews r,cybageemployee e where bookid =? and r.empid=e.empid;");

			pst1.setInt(1, bookId);
			resultSet=pst1.executeQuery();

			if (resultSet.next()) 
			{
				resultSet.previous();
				list1 = new ArrayList<String>();
				while (resultSet.next()) 
				{
					list1.add(resultSet.getString(2)+" : "+ resultSet.getString(1));
				}

			}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}



		try {
			cleanUp();
		} catch (Exception e) {

			e.printStackTrace();
		}
		return list1; 

	}
}
