package utilities;

public class BookReviwes
{
	private int id;
	private int bookId;
	private int userId;
	private String review;
	
	public BookReviwes()
	{	}
	
	public BookReviwes(int id, int bookId, int userId, String review)
	{
		this.id = id;
		this.bookId = bookId;
		this.userId = userId;
		this.review = review;
	}

	public int getId()
	{
		return id;
	}

	public void setId(int id)
	{
		this.id = id;
	}

	public int getBookId()
	{
		return bookId;
	}

	public void setBookId(int bookId)
	{
		this.bookId = bookId;
	}

	public int getUserId()
	{
		return userId;
	}

	public void setUserId(int userId)
	{
		this.userId = userId;
	}

	public String getReview()
	{
		return review;
	}

	public void setReview(String review)
	{
		this.review = review;
	}

	@Override
	public String toString()
	{
		return "BookReviwes [id=" + id + ", bookId=" + bookId + ", userId=" + userId + ", review=" + review + "]";
	}
	
	
}
