package utilities;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class Validate
{
	public static User validateLogin(String email, String pass)
	{
		Connection  con=null;
		
		User user=null;
        try
		{
        	//loading drivers for mysql
			Class.forName("com.mysql.jdbc.Driver");
			
		    //creating connection with the database 
	         con= DriverManager.getConnection("jdbc:mysql://localhost:3306/frdb", "root", "root");
	         
	         PreparedStatement stmt = con.prepareStatement("select id,name,emailId,password,role from Users where emailId=? and password=?");
	         stmt.setString(1, email);
	         stmt.setString(2, pass);
	         ResultSet rs=  stmt.executeQuery();
	         
	         if(rs.next())
	         {
	        	 user = new User();
	        	 user.setId(rs.getInt(1));
	        	 user.setName(rs.getString(2));
	        	 user.setEmailId(rs.getString(3));
	        	 user.setPassword(rs.getString(4));
	        	 user.setRole(rs.getString(5));
	         }
			
		} catch (ClassNotFoundException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        catch(Exception e)
        {
        	e.printStackTrace();
        }
        finally
        {
        	try
			{
        		if(con != null)
					con.close();
			} catch (SQLException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
		return user;
	}
}
