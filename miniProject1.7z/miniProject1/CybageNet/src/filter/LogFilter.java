package filter;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;

import connectionUtil.JdbcConnection;
import pojos.Employee;

/**
 * Servlet Filter implementation class LogFilter
 */

public class LogFilter implements Filter {


	public LogFilter() {
		// TODO Auto-generated constructor stub
	}


	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		
		Employee emp = null;
		String empId=request.getParameter("empid");
		String password=request.getParameter("password");

		
		try(Connection conn=JdbcConnection.getConn()) 
		{
			PreparedStatement pst1 = conn.prepareStatement("Select * from cybageemployee where empid=(?)");
			pst1.setString(1, empId); 
			ResultSet rst=pst1.executeQuery();
			if(rst.next())
			{
				emp = new Employee(rst.getString(1), rst.getString(3),rst.getString(2),rst.getString(4),rst.getString(5)); 

			}
			System.out.println(emp);
			

			
			if(null==emp.getPassword())
			{
				pw.println("<h2 style='color: blue;' align='center' >Either Wrong Employee id /You are Not registered....</h2>");

				RequestDispatcher rd=request.getRequestDispatcher("login.jsp");
				rd.include(request, response);
			}
			else if(!password.equals(emp.getPassword()))
			{
				pw.println("<h2 style='color: blue;' align='center' >WRONG PASSWORD Retry...</h2>");
				RequestDispatcher rd=request.getRequestDispatcher("login.jsp");
				rd.include(request, response);
			}
			else{
				if("A".equalsIgnoreCase(emp.getRole()))
				{
					RequestDispatcher rd=request.getRequestDispatcher("Admin.jsp");
					rd.forward(request, response);
				}
				else
				{
					RequestDispatcher rd=request.getRequestDispatcher("User.jsp");
					rd.forward(request, response);
				}
			}

			

		} 
		catch (ClassNotFoundException e) {
			e.printStackTrace();
		} 
		catch (SQLException e) {
			e.printStackTrace();
		}		


	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
